<?php
    include "./dbcon.php";

    mysqli_set_charset($con, "utf8");
    mysqli_select_db($con, "sqldb");

    $sql = "select user_id from user";
    $ret = mysqli_query($con, $sql);
    if($ret){
		$count = mysqli_num_rows($ret);
    }else{
		echo "실패!! 원인: ".mysqli_error($con);
		exit();
    }

?>

<html>
<head>
  <meta http-equiv="Content-type: content=text/html; charset=utf-8" >
</head>
<body>
<h1> 회원 관리 시스템 </h1>
<a href='select.php'> (1) 회원 조회(조회 후 수전/ 삭제 가능)</a><br><br>
<a href='insert.html'> (2) 신규 회원 등록 </a><br><br>
<form method=get action="update.php">
	(3) 회원 수정 - 회원 아이디 : 
	<select name="user_id">
	<option value="" selected>아이디를 선택해주세요.</option>
	<?php
		 while($row = mysqli_fetch_array($ret)) {
	?>
	<option value="<?php echo $row['user_id'] ?>"><?php echo $row['user_id'] ?></option>
	<?php }?>
<input type=submit value="수정">
</form>
<form method=get action="delete.php">
	(4) 회원 삭제 - 회원 아이디 : 
	<select name="user_id">
	<option value="" selected>아이디를 선택해주세요.</option>
	<?php
		$sql = "select user_id from user";
		$ret = mysqli_query($con, $sql);

		 while($row = mysqli_fetch_array($ret)) {
	?>
	<option value="<?php echo $row['user_id'] ?>"><?php echo $row['user_id'] ?></option>
	<?php }?>
<input type=submit value="삭제">
</form>
</form>
</body>
</html>

