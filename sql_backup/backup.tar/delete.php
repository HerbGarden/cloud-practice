<?php
	$user_id = $_GET['user_id'];
	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "sqldb");

	$sql = "select * from user where user_id='".$user_id."'";
	$ret = mysqli_query($con, $sql);
	if($ret){
		$count = mysqli_num_rows($ret);
		if($count==0){
			echo $user_id." 아이디 회원이 없음!! <br>";
			echo "<br> <a href='main.php'> <--초기 화면</a>";
			exit();
		}
	}
	else{
		echo "실패!!";
		echo "원인:".mysqli_error($con);
		echo "<br> <a href='main.php'> <--초기 화면</a>";
		exit();
	}
	$row = mysqli_fetch_array($ret);
	$user_id = $row['user_id'];
	$name = $row['name'];

	mysqli_close($con);

?>

<html>
<head>
  <meta http-equiv="Content-type: content=text/html; charset=utf-8" >
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

</head>
<body>
<h1> 회원 정보 삭제 </h1>
<form method=post action=delete_result.php accept-charset="utf-8">
<div class="form-group">
    <input type="hidden" name="user_id" value=<?php echo $user_id ?>>
    <p> <b>아이디</b> : <?php echo $user_id?> <p>
  </div>
<div class="form-group">
    <input type="hidden" name="name" value=<?php echo $name ?>>
    <p> <b>이름</b> : <?php echo $name?> <p>
  </div>
<br><br>
위 회원을 삭제하시겠습니까?<br><br>
<input type=submit value="회원 삭제">
</form>
<br>
<div class="text-center">
	<a class="btn btn-default" href="main.php" role="button">초기 화면</a>
</div>
</body>
</html>
