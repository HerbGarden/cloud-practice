<?php
	$name = $_POST["name"];
	$user_id = $_POST["user_id"];
	$birthyear = $_POST["birthyear"];
	$addr = $_POST["addr"];
	$mobile1 = $_POST["mobile1"];
	$mobile2 = $_POST["mobile2"];
	$height = $_POST["height"];
	$mdate = date("Y-m-j");
   
	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "sqldb");

	$sql = "
	INSERT INTO user VALUES
	('".$user_id."','".$name."','".$birthyear."','".$addr."','".$mobile1."','".$mobile2."','".$height."','".$mdate."')";
	$ret = mysqli_query($con, $sql);
	if($ret){
		echo "insert 성공 <br>";
	}else{
		echo "실패!! 원인: ".mysqli_error($con);	
	}

	mysqli_close($con);

	echo "<br> <a href='main.php'> <--초기 화면</a>";
?>
