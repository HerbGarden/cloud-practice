<?php
	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "sqldb");

	$sql = "select * from user";
	$ret = mysqli_query($con, $sql);
	if($ret){
		$count = mysqli_num_rows($ret);
	}else{
		echo "실패!! 원인: ".mysqli_error($con);
		exit();	
	}
?>

<html>
<head>
	<meta http-equiv="Content-type: content=text/html; charset=utf-8" >
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

</head>
<body>
	<h1> 회원 조회 결과 </h1>
	<table class="table table-striped table-bordered table-hover">
	    <thead>
	    	<tr>
	    		<th>아이디</th>
	     		<th>이름</th>
	     		<th>출생연도</th>
	     		<th>지역</th>
	     		<th>국번</th>
	     		<th>전화번호</th>
	     		<th>키</th>
	     		<th>가입일</th>
	     		<th>수정</th>
	     		<th>삭제</th>
	    	</tr>
		</thead>
		<tbody>
		<?php
			while($row = mysqli_fetch_array($ret)) {
		?>
			<tr>
				<td><?php echo $row['user_id'] ?></td>
				<td><?php echo $row['name'] ?></td>
				<td><?php echo $row['birthyear'] ?></td>
				<td><?php echo $row['addr'] ?></td>
				<td><?php echo $row['mobile1'] ?></td>
				<td><?php echo $row['mobile2'] ?></td>
				<td><?php echo $row['height'] ?></td>
				<td><?php echo $row['mdate'] ?></td>
				<td><a href='update.php?user_id=<?php echo $row['user_id'] ?>'>수정</a></td>
				<td><a href='delete.php?user_id=<?php echo $row['user_id'] ?>'>삭제</a></td>
			</tr>
		<?php } ?>
		</tbody>
</table>
<?php
	mysqli_close($con);
?>
<br>
<div class="text-center">
	<a class="btn btn-default" href="main.php" role="button">초기 화면</a>
</div>
</body>
</html>
