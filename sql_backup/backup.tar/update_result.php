<?php
	$name = $_POST["name"];
	$user_id = $_POST["user_id"];
	$birthyear = $_POST["birthyear"];
	$addr = $_POST["addr"];
	$mobile1 = $_POST["mobile1"];
	$mobile2 = $_POST["mobile2"];
	$height = $_POST["height"];
   
	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "sqldb");

	$sql = "update user set name='".$name."', birthyear='".$birthyear."', addr='".$addr."', mobile1='".$mobile1."', mobile2='".$mobile2."', height='".$height."' where user_id = '".$user_id."'";

	$ret = mysqli_query($con, $sql);

	echo "<h1>회원 정보 수정 결과 </h1>";
	if($ret){
		echo "update 성공 <br>";
	}else{
		echo "실패!! 원인: ".mysqli_error($con);	
	}

	mysqli_close($con);

	echo "<br> <a href='main.php'> <--초기 화면</a>";
?>
