<?php
	$user_id = $_POST["user_id"];

	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "sqldb");

	$sql = "delete from user where user_id='".$user_id."'";

	$ret = mysqli_query($con, $sql);

	echo "<h1>회원 정보 삭제  결과 </h1>";
	if($ret){
		echo $user_id." delete 성공 <br>";
	}else{
		echo "실패!! 원인: ".mysqli_error($con);	
	}

	mysqli_close($con);

	echo "<br> <a href='main.php'> <--초기 화면</a>";
?>
