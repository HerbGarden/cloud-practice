<?php
	$user_id = $_GET['user_id'];
	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "sqldb");

	$sql = "select * from user where user_id='".$user_id."'";
	$ret = mysqli_query($con, $sql);
	if($ret){
		$count = mysqli_num_rows($ret);
		if($count==0){
			echo $user_id." 아이디 회원이 없음!! <br>";
			echo "<br> <a href='main.php'> <--초기 화면</a>";
			exit();
		}
	}
	else{
		echo "실패!!";
		echo "원인:".mysqli_error($con);
		echo "<br> <a href='main.php'> <--초기 화면</a>";
		exit();
	}
	$row = mysqli_fetch_array($ret);
	$user_id = $row['user_id'];
	$name = $row['name'];
	$birthyear = $row['birthyear'];
	$addr = $row['addr'];
	$mobile1 = $row['mobile1'];
	$mobile2 = $row['mobile2'];
	$height = $row['height'];
	$mdate = $row['mdate'];


	mysqli_close($con);

?>

<html>
<head>
	<meta http-equiv="Content-type: content=text/html; charset=utf-8" >
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
</head>
<body>
<h1> 회원 정보 수정 </h1>
<form method=post action=update_result.php accept-charset="utf-8">
<div class="form-group">
    <label for="user_id">아이디</label>
    <input type="text" class="form-control" id="user_id"  name="user_id" value=<?php echo $user_id?> readonly>
</div>
<!--
<div class="form-group">
	<input type="hidden" name="user_id" value=<?php echo $user_id ?>>
    <p> <b>아이디</b> : <?php echo $user_id?> <p>
  </div>
-->
<div class="form-group">
    <label for="name">이름</label>
    <input type="text" class="form-control" id="name"  name="name" value=<?php echo $name?>>
  </div>
<div class="form-group">
    <label for="birthyear">출생연도</label>
    <input type="text" class="form-control" id="birthyear"  name="birthyear" value=<?php echo $birthyear?>>
  </div>
<div class="form-group">
    <label for="addr">지역</label>
    <input type="text" class="form-control" id="addr"  name="addr" value=<?php echo $addr?>>
  </div>
<div class="form-group">
    <label for="mobile1">휴대폰 국번</label>
    <input type="text" class="form-control" id="mobile1"  name="mobile1" value=<?php echo $mobile1?>>
  </div>
<div class="form-group">
    <label for="mobile2">휴대폰 전화번호</label>
    <input type="text" class="form-control" id="mobile2"  name="mobile2" value=<?php echo $mobile2?>>
  </div>
<div class="form-group">
    <label for="height">신장</label>
    <input type="text" class="form-control" id="height"  name="height" value=<?php echo $height?>>
  </div>
<div class="form-group">
    <label for="mdate">회원 가입일</label>
    <input type="text" class="form-control" id="mdate"  name="mdate" value=<?php echo $mdate?> readonly>
</div>
<!--
<div class="form-group">
    <p> <b>회원 가입일</b> : <?php echo $mdate?> <p>
  </div>
-->
<br>
<button type="submit" class="btn btn-default">정보수정</button>
<button type="reset" class="btn btn-default">취소</button><br><br>
<div class="text-center">
<a class="btn btn-default" href="main.php" role="button">초기 화면</a>
</div>
</form>
</body>
</html>
