<?php
	$goods_code = $_POST["goods_code"];
	$manuf = $_POST["manuf"];
	$model = $_POST["model"];
	$price = $_POST["price"];
	$note = $_POST["note"];
   
	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "noteshop");

	$sql = "
	INSERT INTO goods VALUES
	('".$goods_code."','".$manuf."','".$model."','".$price."','".$note."')";
	$ret = mysqli_query($con, $sql);
	if($ret){
		echo "제품 입력 성공 <br>";
	}else{
		echo "실패!! 원인: ".mysqli_error($con);	
	}

	mysqli_close($con);

	echo "<br> <a href='noteshop.php'> <--초기 화면</a>";
?>
