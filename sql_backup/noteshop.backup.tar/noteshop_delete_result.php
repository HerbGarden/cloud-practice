<?php
	$list = $_POST['list'];	

	if($list == "user"){
        $user_id = $_POST["user_id"];
    }elseif($list == "goods"){
        $goods_code = $_POST["goods_code"];
    }elseif($list == "buy"){
        $num = $_POST["num"];
    }
	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "noteshop");
	
	if($list == "user"){
		$sql = "delete from ".$list." where user_id='".$user_id."'";
    }elseif($list == "goods"){
		$sql = "delete from ".$list." where goods_code='".$goods_code."'";
    }elseif($list == "buy"){
		$sql = "delete from ".$list." where num='".$num."'";
	}
	$ret = mysqli_query($con, $sql);

	echo "<h1>삭제  결과 </h1>";
	if($ret){
		if($list == "user"){
			echo $user_id." delete 성공 <br>";
	    }elseif($list == "goods"){
			echo $goods_code." delete 성공 <br>";
	    }elseif($list == "buy"){
			echo $num." delete 성공 <br>";
	    }
	}else{
		echo "실패!! 원인: ".mysqli_error($con);	
	}

	mysqli_close($con);

	echo "<br> <a href='noteshop.php'> <--초기 화면</a>";
?>
