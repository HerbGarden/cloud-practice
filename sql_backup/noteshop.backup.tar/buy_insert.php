<?php
    include "./dbcon.php";

    mysqli_set_charset($con, "utf8");
    mysqli_select_db($con, "noteshop");

    $sql1 = "select user_id from user";
    $sql2 = "select goods_code from goods";
    $ret1 = mysqli_query($con, $sql1);
    $ret2 = mysqli_query($con, $sql2);
    if($ret1 or $ret2){
        $count1 = mysqli_num_rows($ret1);
        $count2 = mysqli_num_rows($ret2);
    }else{
        echo "실패!! 원인: ".mysqli_error($con);
        exit();
    }

?>

<html>
<head>
  <meta http-equiv="Content-type: content=text/html; charset=utf-8" >
	<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<body>
<h1> 신규 제품 등록 </h1>

<form class="form-horizontal" method=post action=buy_insert_result.php accept-charset="utf-8">
	<fieldset>
	    <div id="legend">
			<legend class=""></legend>
    	</div>
 
    <div class="control-group">
		<label class="control-label" for="user_id">아이디</label>
			<div class="controls">
				<select name="user_id" id="user_id" class="input-xlarge">
			    <option value="" selected>아이디를 선택해주세요.</option>
    			<?php
        			 while($row = mysqli_fetch_array($ret1)) {
   				 ?>
   				 <option value="<?php echo $row['user_id'] ?>"><?php echo $row['user_id'] ?></option>
   				 <?php }?>
				</select>
			</div>
    </div>
 
    <div class="control-group">
		<label class="control-label" for="goods_code">상품코드</label>
			<div class="controls">
				<select id="goods_code" name="goods_code" class="input-xlarge">
		    	<option value="" selected>상품코드를 선택해주세요.</option>
		    	<?php
    			     while($row = mysqli_fetch_array($ret2)) {
   				 ?>
   				 <option value="<?php echo $row['goods_code'] ?>"><?php echo $row['goods_code'] ?></option>
   				 <?php }?>
				</select>
			</div>
    </div>
 
    <div class="control-group">
		<label class="control-label" for="count">구매개수</label>
			<div class="controls">
  				<input type="text" id="count" name="count" class="input-xlarge">
			</div>
    </div>
<!-- 
    <div class="control-group">
		<label class="control-label" for="total">전체가격</label>
			<div class="controls">
  				<input type="text" id="total" name="total" class="input-xlarge" ">
			</div>
    </div>
-->
    <div class="control-group">
<!-- Button -->
		<div class="controls">
			<button type="submit" class="btn btn-success">구매 등록</button>
			<button type="reset" class="btn btn-success">취소</button>
		</div>
    </div>
  </fieldset>
</form>
<div class="text-center">
	<a class="btn btn-default" href="noteshop.php" role="button">초기 화면</a>
</div>
</body>
</html>
