<?php
	$goods_code = $_POST["goods_code"];
	$user_id = $_POST["user_id"];
	$count = $_POST["count"];
   
	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "noteshop");

	$sql = "select price from goods where goods_code='".$goods_code."'";
	$ret = mysqli_query($con, $sql);
	if($ret){
		echo "구매 정보 입력 성공  <br>";
	}else{
		echo "실패!! 원인: ".mysqli_error($con);
		exit();	
	}
	$row = mysqli_fetch_array($ret);
	$total = (int)$count * (int)$row['price'];

	$sql = "
	INSERT INTO buy VALUES
	('null','".$user_id."','".$goods_code."','".$count."','".$total."')";
	$ret = mysqli_query($con, $sql);
	if($ret){
		echo "제품 입력 성공 <br>";
	}else{
		echo "실패!! 원인: ".mysqli_error($con);	
	}

	mysqli_close($con);

	echo "<br> <a href='noteshop.php'> <--초기 화면</a>";
?>
