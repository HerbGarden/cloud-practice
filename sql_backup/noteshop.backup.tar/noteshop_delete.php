<?php
	$list = $_GET['list'];

	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "noteshop");

	if($list == "user"){
        $user_id = $_GET['user_id'];
        $sql = "select * from ".$list." where user_id='".$user_id."'";
    }
    elseif($list == "goods"){
        $goods_code = $_GET['goods_code'];
        $sql = "select * from ".$list." where goods_code='".$goods_code."'";
    }
    elseif($list == "buy"){
        $num = $_GET['num'];
        $sql = "select * from ".$list." where num='".$num."'";
    }
	
	$ret = mysqli_query($con, $sql);
	if($ret){
		$count = mysqli_num_rows($ret);
		if($count==0){
			echo "찾는 데이터가  없습니다!! <br>";
			echo "<br> <a href='noteshop.php'> <--초기 화면</a>";
			exit();
		}
	}
	else{
		echo "실패!!";
		echo "원인:".mysqli_error($con);
		echo "<br> <a href='noteshop.php'> <--초기 화면</a>";
		exit();
	}
	$row = mysqli_fetch_array($ret);
    if($list == "user"){
        $user_id = $row['user_id'];
        $name = $row['name'];
    }elseif($list == "goods"){
        $goods_code = $row['goods_code'];
        $manuf = $row['manuf'];
        $model = $row['model'];
    }elseif($list == "buy"){
        $num = $row['num'];
        $user_id = $row['user_id'];
        $goods_code = $row['goods_code'];
        $count = $row['count'];
        $total = $row['total'];
    }

	mysqli_close($con);

?>

<html>
<head>
  <meta http-equiv="Content-type: content=text/html; charset=utf-8" >
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

</head>
<body>
<?php
if($list == "user"){
?>
<h1> 회원 정보 삭제 </h1>
<form method=post action=noteshop_delete_result.php accept-charset="utf-8">
<input type="hidden" name="list" value=<?php echo $list ?>>
<div class="form-group">
    <input type="hidden" name="user_id" value=<?php echo $user_id ?>>
    <p> <b>아이디</b> : <?php echo $user_id?> <p>
  </div>
<div class="form-group">
    <input type="hidden" name="name" value=<?php echo $name ?>>
    <p> <b>이름</b> : <?php echo $name?> <p>
  </div>
<br><br>
위 회원을 삭제하시겠습니까?<br><br>
<input type=submit value="회원 삭제">
<?php }
elseif($list == "goods"){
?>
<h1> 제품 정보 삭제 </h1>
<form method=post action=noteshop_delete_result.php accept-charset="utf-8">
<input type="hidden" name="list" value=<?php echo $list ?>>
<div class="form-group">
    <input type="hidden" name="goods_code" value=<?php echo $goods_code ?>>
    <p> <b>상품코드</b> : <?php echo $goods_code?> <p>
  </div>
<div class="form-group">
    <p> <b>제조사</b> : <?php echo $manuf?> <p>
  </div>
<div class="form-group">
    <p> <b>모델명</b> : <?php echo $model?> <p>
  </div>
<br><br>
위 상품을 삭제하시겠습니까?<br><br>
<input type=submit value="상품 삭제">
<?php
}elseif($list == "buy"){
?>
<h1> 구매 정보 삭제 </h1>
<form method=post action=noteshop_delete_result.php accept-charset="utf-8">
<input type="hidden" name="list" value=<?php echo $list ?>>
<div class="form-group">
    <input type="hidden" name="num" value=<?php echo $num ?>>
    <p> <b>번호</b> : <?php echo $num?> <p>
  </div>
<div class="form-group">
    <p> <b>아이디</b> : <?php echo $user_id?> <p>
  </div>
<div class="form-group">
    <p> <b>상품코드</b> : <?php echo $goods_code?> <p>
  </div>
<div class="form-group">
    <p> <b>구매개수</b> : <?php echo $count?> <p>
  </div>
<div class="form-group">
    <p> <b>전체가격</b> : <?php echo $total?> <p>
  </div>
<br><br>
위 구매 정보을 삭제하시겠습니까?<br><br>
<input type=submit value="구매 정보 삭제">
<?php
}
?>
</form>
<br>
<div class="text-center">
	<a class="btn btn-default" href="noteshop.php" role="button">초기 화면</a>
</div>
</body>
</html>
