<?php
	$list = $_POST['list'];

	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "noteshop");

	$sql = "select * from ".$list;
	$ret = mysqli_query($con, $sql);
	if($ret){
		$count = mysqli_num_rows($ret);
	}else{
		echo "실패!! 원인: ".mysqli_error($con);
		exit();	
	}
?>

<html>
<head>
	<meta http-equiv="Content-type: content=text/html; charset=utf-8" >
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

</head>
<body>
	<h1> 회원 조회 결과 </h1>
	<table class="table table-striped table-bordered table-hover">
	    <thead>
	    	<tr>
				<?php
				if($list == "goods"){
				?>
	    		<th>상품코드</th>
	     		<th>제조사</th>
	     		<th>모델명</th>
	     		<th>가격</th>
	     		<th>기타</th>
				<th>수정</th>
	     		<th>삭제</th>
				<?php }
				elseif($list == "user"){
				?>
				<th>아이디</th>
                <th>이름</th>
                <th>비밀번호</th>
                <th>성별</th>
                <th>핸드폰</th>
                <th>가입일</th>
                <th>주소</th>
				<th>수정</th>
	     		<th>삭제</th>
				<?php }
				elseif($list == "buy"){
				?>
				<th>번호</th>
                <th>아이디</th>
                <th>상품코드</th>
                <th>구매개수</th>
                <th>전체가격</th>
				<th>수정</th>
	     		<th>삭제</th>
				<?php } ?>
	    	</tr>
		</thead>
		<tbody>
		<?php
			while($row = mysqli_fetch_array($ret)) {
		?>
			<tr>
				<?php
				if($list == "goods"){
				?>
				<td><?php echo $row['goods_code'] ?></td>
				<td><?php echo $row['manuf'] ?></td>
				<td><?php echo $row['model'] ?></td>
				<td><?php echo $row['price'] ?></td>
				<td><?php echo $row['note'] ?></td>
				<td><a href='noteshop_update.php?goods_code=<?php echo $row['goods_code']."&list=".$list ?>'>수정</a></td>
				<td><a href='noteshop_delete.php?goods_code=<?php echo $row['goods_code']."&list=".$list ?>'>삭제</a></td>
				<?php }
				elseif($list == "user"){
				?>
				<td><?php echo $row['user_id'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td>**********</td>
                <td><?php echo $row['sex'] ?></td>
                <td><?php echo $row['phone'] ?></td>
                <td><?php echo $row['mdate'] ?></td>
                <td><?php echo $row['addr'] ?></td>
				<td><a href='noteshop_update.php?user_id=<?php echo $row['user_id']."&list=".$list ?>'>수정</a></td>
				<td><a href='noteshop_delete.php?user_id=<?php echo $row['user_id']."&list=".$list ?>'>삭제</a></td>
				<?php }
				elseif($list == "buy"){
				?>
				<td><?php echo $row['num'] ?></td>
                <td><?php echo $row['user_id'] ?></td>
                <td><?php echo $row['goods_code'] ?></td>
			     <td><?php echo $row['count'] ?></td>
                <td><?php echo $row['total'] ?></td>
				<td><a href='noteshop_update.php?num=<?php echo $row['num']."&list=".$list ?>'>수정</a></td>
				<td><a href='noteshop_delete.php?num=<?php echo $row['num']."&list=".$list ?>'>삭제</a></td>
				<?php } ?>
			</tr>
		<?php } ?>
		</tbody>
</table>
<?php
	mysqli_close($con);
?>
<br>
<div class="text-center">
	<a class="btn btn-default" href="noteshop.php" role="button">초기 화면</a>
</div>
</body>
</html>
