<?php
    include "./dbcon.php";

    mysqli_set_charset($con, "utf8");
    mysqli_select_db($con, "noteshop");

    $sql = "select user_id from user";
    $ret = mysqli_query($con, $sql);
    if($ret){
		$count = mysqli_num_rows($ret);
    }else{
		echo "실패!! 원인: ".mysqli_error($con);
		exit();
    }

?>

<html>
<head>
  <meta http-equiv="Content-type: content=text/html; charset=utf-8" >
</head>
<body>
<h1> 상품 관리 시스템 </h1>
<!--
<a href='user_select.php'> 회원 조회(조회 후 수정/ 삭제 가능)</a><br><br>
<a href='goods_select.php'> 제품 조회(조회 후 수정/ 삭제 가능)</a><br><br>
<a href='buy_select.php'> 구매 조회(조회 후 수정/ 삭제 가능)</a><br><br>
-->
<form method=post action="all_list.php">
<select name="list">
    <option value="" selected>원하는 table을 선택해주세요.</option>
    <option value="user">회원 조회</option>
    <option value="goods">제품 조회</option>
    <option value="buy">구매 조회</option>
<input type=submit value="선택">
</form>
<a href='user_insert.html'> 신규 회원 등록 </a><br><br>
<a href='goods_insert.html'> 신규 제품 등록 </a><br><br>
<a href='buy_insert.php'> 구매 등록 </a><br><br>
<!--
<form method=get action="update.php">
	(3) 회원 수정 - 회원 아이디 : 
	<select name="user_id">
	<option value="" selected>아이디를 선택해주세요.</option>
	<?php
		 while($row = mysqli_fetch_array($ret)) {
	?>
	<option value="<?php echo $row['user_id'] ?>"><?php echo $row['user_id'] ?></option>
	<?php }?>
<input type=submit value="수정">
</form>
<form method=get action="delete.php">
	(4) 회원 삭제 - 회원 아이디 : 
	<select name="user_id">
	<option value="" selected>아이디를 선택해주세요.</option>
	<?php
		$sql = "select user_id from user";
		$ret = mysqli_query($con, $sql);

		 while($row = mysqli_fetch_array($ret)) {
	?>
	<option value="<?php echo $row['user_id'] ?>"><?php echo $row['user_id'] ?></option>
	<?php }?>
<input type=submit value="삭제">
</form>
-->
</body>
</html>

