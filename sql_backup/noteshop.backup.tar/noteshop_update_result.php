<?php
	$list = $_POST['list'];
	if($list == "user"){
		$name = $_POST["name"];
		$user_id = $_POST["user_id"];
		$passwd = $_POST["passwd"];
		$addr = $_POST["addr"];
		$sex = $_POST["sex"];
		$phone = $_POST["phone"];
    }elseif($list == "goods"){
		$goods_code = $_POST["goods_code"];
		$manuf = $_POST["manuf"];
		$model = $_POST["model"];
		$price = $_POST["price"];
		$note = $_POST["note"];
    }elseif($list == "buy"){
		$num = $_POST["num"];
		$user_id = $_POST["user_id"];
		$goods_code = $_POST["goods_code"];
		$count = $_POST["count"];
		$total = $_POST["total"];
    }
   
	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "noteshop");

	if($list == "user"){
		$sql = "update user set name='".$name."', passwd='".$passwd."', addr='".$addr."', sex='".$sex."', phone='".$phone."' where user_id = '".$user_id."'";
    }elseif($list == "goods"){
		$sql = "update goods set manuf='".$manuf."', model='".$model."', goods_code='".$goods_code."', price='".$price."', note='".$note."' where goods_code = '".$goods_code."'";
    }elseif($list == "buy"){
/*
		$sql = "select price from goods where goods_code='".$goods_code."'";
		$ret = mysqli_query($con, $sql);
		if($ret){
		}else{
			echo "실패!! 원인: ".mysqli_error($con);
			exit();	
		}
		$row = mysqli_fetch_array($ret);
		$price = $row['price'];		
*/	
		$sql = "update buy set user_id='".$user_id."', goods_code='".$goods_code."', count='".$count."', total='".$total."' where num = '".$num."'";
    }

	$ret = mysqli_query($con, $sql);

	echo "<h1>정보 수정 결과 </h1>";
	if($ret){
		echo "update 성공 <br>";
	}else{
		echo "실패!! 원인: ".mysqli_error($con);	
	}

	mysqli_close($con);

	echo "<br> <a href='noteshop.php'> <--초기 화면</a>";
?>
