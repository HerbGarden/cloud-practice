<?php
	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "noteshop");

	$sql = "select * from goods";
	$ret = mysqli_query($con, $sql);
	if($ret){
		$count = mysqli_num_rows($ret);
	}else{
		echo "실패!! 원인: ".mysqli_error($con);
		exit();	
	}
?>

<html>
<head>
	<meta http-equiv="Content-type: content=text/html; charset=utf-8" >
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

</head>
<body>
	<h1> 회원 조회 결과 </h1>
	<table class="table table-striped table-bordered table-hover">
	    <thead>
	    	<tr>
	    		<th>상품코드</th>
	     		<th>제조사</th>
	     		<th>모델명</th>
	     		<th>가격</th>
	     		<th>기타</th>
	     		<!--
				<th>수정</th>
	     		<th>삭제</th>
				-->
	    	</tr>
		</thead>
		<tbody>
		<?php
			while($row = mysqli_fetch_array($ret)) {
		?>
			<tr>
				<td><?php echo $row['goods_code'] ?></td>
				<td><?php echo $row['manuf'] ?></td>
				<td><?php echo $row['model'] ?></td>
				<td><?php echo $row['price'] ?></td>
				<td><?php echo $row['note'] ?></td>
				<!--<td><a href='goods_update.php?user_id=<?php echo $row['user_id'] ?>'>수정</a></td>
				<td><a href='goods_delete.php?user_id=<?php echo $row['user_id'] ?>'>삭제</a></td>
			-->
			</tr>
		<?php } ?>
		</tbody>
</table>
<?php
	mysqli_close($con);
?>
<br>
<div class="text-center">
	<a class="btn btn-default" href="noteshop.php" role="button">초기 화면</a>
</div>
</body>
</html>
