<?php
	$name = $_POST["name"];
	$user_id = $_POST["user_id"];
	$passwd = $_POST["passwd"];
	$addr = $_POST["addr"];
	$phone = $_POST["phone"];
	$sex = $_POST["sex"];
	$mdate = date("Y-m-j");
   
	include "./dbcon.php";
 
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "noteshop");

	$sql = "
	INSERT INTO user VALUES
	('".$user_id."','".$name."','".$passwd."','".$sex."','".$phone."','".$mdate."','".$addr."')";
	$ret = mysqli_query($con, $sql);
	if($ret){
		echo "회원 입력 성공 <br>";
	}else{
		echo "실패!! 원인: ".mysqli_error($con);	
	}

	mysqli_close($con);

	echo "<br> <a href='noteshop.php'> <--초기 화면</a>";
?>
