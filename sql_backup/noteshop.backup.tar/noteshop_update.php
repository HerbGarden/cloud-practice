<?php
	$list = $_GET['list'];
	
	include "./dbcon.php";
	
	mysqli_set_charset($con, "utf8");
	mysqli_select_db($con, "noteshop");

	if($list == user){
		$user_id = $_GET['user_id'];
		$sql = "select * from ".$list." where user_id='".$user_id."'";
	}
	elseif($list == goods){
		$goods_code = $_GET['goods_code'];
		$sql = "select * from ".$list." where goods_code='".$goods_code."'";
	}	
	elseif($list == buy){
		$num = $_GET['num'];
		$sql = "select * from ".$list." where num='".$num."'";
	}
	$ret = mysqli_query($con, $sql);
	if($ret){
		$count = mysqli_num_rows($ret);
		if($count==0){
			echo "찾는 데이터가  없음!! <br>";
			echo "<br> <a href='noteshop.php'> <--초기 화면</a>";
			exit();
		}
	}
	else{
		echo "실패!!";
		echo "원인:".mysqli_error($con);
		echo "<br> <a href='main.php'> <--초기 화면</a>";
		exit();
	}
	$row = mysqli_fetch_array($ret);
	if($list == "user"){
		$user_id = $row['user_id'];
        $name = $row['name'];
        $passwd = $row['passwd'];
		$sex = $row['sex'];
        $phone = $row['phone'];
        $mdate = $row['mdate'];
        $addr = $row['addr'];
	}elseif($list == "goods"){
		$goods_code = $row['goods_code'];
		$manuf = $row['manuf'];
		$model = $row['model'];
		$price = $row['price'];
		$note = $row['note'];
	}elseif($list == "buy"){
		$num = $row['num'];
		$user_id = $row['user_id'];
		$goods_code = $row['goods_code'];
		$count = $row['count'];
		$total = $row['total'];
	}
	
	mysqli_close($con);

?>

<html>
<head>
	<meta http-equiv="Content-type: content=text/html; charset=utf-8" >
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
</head>
<body>
<?php
if($list == "user"){
?>
<h1> 회원 정보 수정 </h1>
<form method=post action=noteshop_update_result.php accept-charset="utf-8">
<input type="hidden" name="list" value=<?php echo $list ?>>
<div class="form-group">
	<input type="hidden" name="user_id" value=<?php echo $user_id ?>>
    <p> <b>아이디</b> : <?php echo $user_id?> <p>
  </div>
<div class="form-group">
    <label for="name">이름</label>
    <input type="text" class="form-control" id="name"  name="name" value=<?php echo $name?>>
  </div>
<div class="form-group">
    <label for="passwd">비밀번호</label>
    <input type="password" class="form-control" id="passwd"  name="passwd" value=<?php echo $passwd?>>
  </div>
<div class="form-group">
    <label for="sex">성별</label>
    <input type="text" class="form-control" id="sex"  name="sex" value=<?php echo $sex?>>
  </div>
<div class="form-group">
    <label for="phone">핸드폰</label>
    <input type="text" class="form-control" id="phone"  name="phone" value=<?php echo $phone?>>
  </div>
<div class="form-group">
	<input type="hidden" name="mdate" value=<?php echo $mdate ?>>
    <p> <b>회원 가입일</b> : <?php echo $mdate?> <p>
</div>
<div class="form-group">
    <label for="addr">주소</label>
    <input type="text" class="form-control" id="addr"  name="addr" value="<?php echo $addr ?>">
</div>
<?php }
elseif($list == "goods"){
?>
<h1> 제품 정보 수정 </h1>
<form method=post action=noteshop_update_result.php accept-charset="utf-8">
<input type="hidden" name="list" value=<?php echo $list ?>>
<div class="form-group">
    <label for="goods_code">상품코드</label>
    <input type="text" class="form-control" id="goods_code"  name="goods_code" value=<?php echo $goods_code?>>
  </div>
<div class="form-group">
    <label for="manuf">제조사</label>
    <input type="text" class="form-control" id="manuf"  name="manuf" value=<?php echo $manuf?>>
  </div>
<div class="form-group">
    <label for="model">모델명</label>
    <input type="text" class="form-control" id="model"  name="model" value=<?php echo $model?>>
  </div>
<div class="form-group">
    <label for="price">가격</label>
    <input type="text" class="form-control" id="price"  name="price" value=<?php echo $price?>>
  </div>
<div class="form-group">
    <label for="note">기타</label>
    <input type="text" class="form-control" id="note"  name="note" value=<?php echo $note?>>
  </div>
<?php
}elseif($list == "buy"){
?>   
<h1> 구매 정보 수정 </h1>
<form method=post action=noteshop_update_result.php accept-charset="utf-8">
<input type="hidden" name="list" value=<?php echo $list ?>>
<div class="form-group">
	<input type="hidden" name="num" value=<?php echo $num ?>>
    <p> <b>번호</b> : <?php echo $num?> <p>
  </div>
<div class="form-group">
    <label for="user_id">아이디</label>
    <input type="text" class="form-control" id="user_id"  name="user_id" value=<?php echo $user_id?>>
  </div>
<div class="form-group">
    <label for="goods_code">상품코드</label>
    <input type="text" class="form-control" id="goods_code"  name="goods_code" value=<?php echo $goods_code?>>
  </div>
<div class="form-group">
    <label for="count">구매개수</label>
    <input type="text" class="form-control" id="count"  name="count" value=<?php echo $count?>>
  </div>
<div class="form-group">
    <label for="total">전체가격</label>
    <input type="text" class="form-control" id="total"  name="total" value=<?php echo $total?>>
  </div>
<!--
<div class="form-group">
    <p> <b>전체가격</b> : <?php echo $total?> <p>
</div>
-->
<?php
}
?>
<br>
<button type="submit" class="btn btn-default">정보수정</button>
<button type="reset" class="btn btn-default">취소</button><br><br>
<div class="text-center">
<a class="btn btn-default" href="noteshop.php" role="button">초기 화면</a>
</div>
</form>
</body>
</html>
